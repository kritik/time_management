# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TimeManagement::Application.config.secret_token = 'c349632bedbba6fe60c156b38e5dae5df63270cd5ff72aeb0634cf0548c2e1ff983f5d61c6e8cc88d4b1bed99b03f80a354143f7126f0bdcda57fd9368afb423'
