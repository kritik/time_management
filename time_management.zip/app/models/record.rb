class Record < ActiveRecord::Base
  validates_numericality_of :start, :greater_than_or_equal_to =>0, :less_than => 24
  validates_numericality_of :duration, :greater_than =>0, :less_than => 24
  validates :date, :presence => true,
                    :format => {:with => /^([0-3][0-9]-[0-1][0-9]-[12][0-9]{3})$/}

  belongs_to :user
  
  scope :users, lambda{ |user_id| where(:user_id => user_id)}
  default_scope order("date ASC")

  # to have method to calculate when working day was ended
  def ends
    self.start + self.duration
  end

  # calculates duration and makes all times from string to decimal
  def self.extend_params_with params = {}
    record = params[:record]
    unless record.nil?
      record[:start] = hours_to_numeric(record[:start])
      record[:duration] = hours_to_numeric(record[:duration])
      params[:ends] = hours_to_numeric(params[:ends])

      if params[:ends] >= 0 && record[:duration] == 0
        params[:record][:duration] = params[:ends] - record[:start]
      end
    end
    params
  end

  # converst human time to float
  # i.e. "09:30" to 9.5 or "9:45" to 9.75 etc
  def self.hours_to_numeric(hours)
    return 0 if hours.blank?
    
    if hours.to_s.include? ":"
      left = hours[0,hours.index(":")].to_i
      right = hours[hours.index(":")+1,2].to_i
      return left + (((right * 5) / 3) / 100.to_f)
    else
      return hours.to_s.gsub(",",".").to_f
    end
  end

  # converts float to human time
  # i.e. 9.5 to 9:30 or 8.75 to 8:45 etc
  def self.numeric_to_hours(hours)
    return "0:00" if hours.nil? || hours == 0
    hrs_i = hours.to_i
    hrs_f = hours.to_f
    if hrs_i != 0
      units = hrs_f % hrs_i
    else
      units = hrs_f
    end
    units = ((units / 5) * 300)
    hrs_s = "#{hours.to_i.to_s}:#{units.to_i.to_s.rjust(2, "0")}"
    hrs_s += "0" if hrs_s =~ /:0$/
    return hrs_s
  end

  # get current time with columns
  def self.get_time_as_string
    hours_to_numeric("#{Time.new.hour}:#{Time.new.min}")
  end

  # it is needed to have date in correct format for js
  # it is here to keep in one place
  def self.get_date
    Time.now.strftime(Date::DATE_FORMATS[:default])
  end

end
